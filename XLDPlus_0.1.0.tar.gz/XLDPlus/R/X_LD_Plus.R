#' @title Scalable computing for complex LD spectra across species
#' @description Methods to efficiently calculate complex LD patterns for biobank-scale sample.
#' @param input Specify the genotype files in PLINK binary format.
#' @param output The output prefix along with the path where the results will be stored.
#' @param maf Filters out all variants with minor allele frequency below the provided threshold (default 0.05).
#' @param geno Filters out all variants with missing call rates exceeding the provided value (default 0.2).
#' @param autosome Excludes all unplaced and non-autosomal variants (default 22).
#' @param population_type Specify the population type (default outbred). If the population is inbred, such as Arabidopsis or rice, please select inbred.
#' @param memory  Set size, in MiB, of initial workspace malloc (default 10000).
#' @param threads Specify the number of threads on which the program will be running (default 1).
#' @param B Specify the number of iterations (default 100).
#'
#' @export
#' @import utils stats ggplot2 data.table

X_LD_Plus <- function(input=NULL,
                      output=NULL,
                      population_type=c("outbred","inbred"),
                      maf=0.05,
                      geno=0.2,
                      autosome=22,
                      memory=10000,
                      threads=1,
                      B=100){
  #  Check inputs
  if(!(file.exists(paste0(input,".bed"))))
    stop("The bed file doesn't exist.")
  if(!(file.exists(paste0(input,".bim"))))
    stop("The bim file doesn't exist.")
  if(!(file.exists(paste0(input,".fam"))))
    stop("The fam file doesn't exist.")

  if(is.null(output))
    stop("Output is NULL")

  if(maf > 0.5 || maf <0)
    stop("MAF must be >= 0 & <= 0.5")

  if(geno > 1 || geno <0)
    stop("Missing call rates must be >= 0 & <= 1")

  if(trunc(autosome)-autosome !=0 || autosome < 0)
    stop("Autosome number should be a single positive integer")
  if(trunc(memory)-memory !=0 || memory < 0)
    stop("Memory should be a single positive integer")
  if(trunc(threads)-threads !=0 || threads < 0)
    stop("Threads should be a single positive integer")
  if(trunc(B)-B !=0 || B < 0)
    stop("The number of iterations should be a single positive integer")

  population_type <- match.arg(population_type)

  options (warn = -1)
  # Detect software
  pkg_dir <- find.package("XLDPlus")
  exe_path <- paste0(pkg_dir,"/exec/")
  zip::unzip(paste0(exe_path,"plink2.zip"),overwrite=T,exdir=exe_path)
  if(length(grep("linux",utils::sessionInfo()$platform, ignore.case = TRUE))>0) {
    system(paste0("chmod a+x ",exe_path,"plink2_linux"))
    plink2 = paste0(exe_path,"plink2_linux")
  } else if(length(grep("apple",utils::sessionInfo()$platform, ignore.case = TRUE))>0) {
    system(paste0("chmod a+x ",exe_path,"plink2_mac"))
    plink2 = paste0(exe_path,"plink2_mac")
  } else {
    print("Don't support Windows")
  }

  if(population_type=="inbred"){
    sc = 2
  }else if(population_type=="outbred"){
    sc = 1
  }

  # Quality control
  cat("QC...\nExtract autosome SNP variants...\n\n")
  QC1 = paste0(plink2, " --bfile ", input, " --chr-set ", autosome, " --allow-extra-chr --set-missing-var-ids @:# --autosome --snps-only --threads ",
               threads, " --memory ",memory , " --make-bed --out ", output,".1.autosome.snp")
  system(QC1)

  cat("\nQC...\nMAF and missing call rates...\n\n")
  QC2 = paste0(plink2, " --bfile ", output, ".1.autosome.snp --chr-set ", autosome, " --maf ", maf, " --geno ", geno, " --threads ",
               threads, " --memory ",memory , " --make-bed --out ", output,".3.core")
  system(QC2)
  system(paste0("rm ",output,".1.autosome.snp*"))

  nIND <- nrow(read.table(paste0(output, ".3.core.fam"), as.is = T, header = F, colClasses = c("character","NULL","NULL","NULL","NULL","NULL")))
  nSNP <- nrow(read.table(paste0(output, ".3.core.bim"), as.is = T, header = F, colClasses = c("character","NULL","NULL","NULL","NULL","NULL")))
  # Generate Zb
  system(paste0("echo '#FID\tIID\t", paste0("zb", 1:B, collapse = '\t'), "' >",output,".head.tmp"))
  system(paste0("awk 'BEGIN{OFS=\"\t\"}{print $1,$2}' ", output,".3.core.fam > ",output,".id.tmp"))

  zb = matrix(NA, nIND, B)
  zb = apply(zb, 2, assign.random)

  write.table(zb, paste0(output,".zb.tmp"), quote = F, col.names = F, row.names = F, sep = '\t')
  system(paste0("paste -d \"\t\" ",paste0(output,".id.tmp "), paste0(output,".zb.tmp")," > ",output,".idzb.tmp"))
  system(paste0("cat ",output,".head.tmp ",output,".idzb.tmp > ",output,".zb.txt"))

  # Output files
  chrLD <- data.frame(matrix(NA,nrow=autosome*(autosome+1)/2,ncol=7))
  colnames(chrLD) <- c("chri","chrj","marker number","LD","var(LD)","SE(LD)","p")
  tmp <- rbind(cbind(c(1:autosome),c(1:autosome)),t(combn(autosome,2)))
  chrLD[,c(1,2)] <- tmp[order(tmp[,1],tmp[,2]),]

  # Intra-chromosomal LD
  for(k in 1:autosome){
    nchrSNP = system(paste0("cat ",output,".3.core.bim | grep -w '^",k,"' | wc -l"),intern = TRUE)
    nchrSNP <- as.numeric(nchrSNP)

    if(nchrSNP == 0){
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),3] <- NA
      next
    }else{
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),3] <- nchrSNP

      system(paste0(plink2," --bfile ", output,".3.core --chr ",k," --chr-set ",autosome," --allow-extra-chr --allow-no-sex --no-psam-pheno --glm allow-no-covars --pheno ",
                    output,".zb.txt"," --threads ",threads, " --memory ", memory, " --out ",output,".3.core.chr",k))


      cmd = paste0("awk 'BEGIN{OFS=\"\\t\"}(NR>1){print $3,$6,$11*sqrt($8)}' ",output,".3.core.chr",k, ".zb1.glm.linear > ", output,".chr",k,".xzb.1.tmp")
      system(cmd)

      cmd = paste0("paste ", paste0("<(awk 'BEGIN{OFS=\"\\t\"}(NR>1){print $11*sqrt($8)}' ", output,".3.core.chr",k, ".zb", 2:B, ".glm.linear) ", collapse = ""), " > ",
                   output,".chr",k,".xzb.2.tmp", collapse = "")
      write("#!/bin/bash\n", paste0(output,".scoring.construct.bash"))
      write(cmd, paste0(output,".scoring.construct.bash"), append = T)
      system(paste0("bash ",output,".scoring.construct.bash"))

      cmd = paste0("paste ",output,".chr",k,".xzb.1.tmp ",output,".chr",k, ".xzb.2.tmp > ",output,".chr",k,".xzb.tmp")
      system(cmd)


      system(paste0(plink2," --bfile ",output, ".3.core --chr-set ",autosome, " --chr ",k," --freq --threads ",threads, " --memory ",
                    memory," --out ",output,".3.core.chr",k))


      system(paste0(plink2," --bfile ",output, ".3.core --chr-set ",autosome, " --chr ",k," --no-psam-pheno --read-freq ", output,".3.core.chr",k,".afreq --score ",
                    output,".chr",k,".xzb.tmp"," 1 2 variance-standardize --score-col-nums 3-", 2+B, " --threads ",threads, " --memory ", memory," --out ", output,".3.core.chr",k))


      xxz = data.frame(fread(paste0(output,".3.core.chr",k, ".sscore"), header = T))
      xxz = as.matrix(xxz[,3]*xxz[,c(5:ncol(xxz))])
      SS = colSums(xxz^2, na.rm = T)

      LB = SS/(nchrSNP^2)
      trK2 = (sum(SS)/(nchrSNP^2))*(1/B)*(1/as.numeric(sc))

      # LD
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),4] = (trK2-nIND)/(nIND*(nIND+1))

      # variance
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),5] = (1/(nIND*(nIND-1)))^2*var(LB)/B

      # SE
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),6] = sqrt(chrLD[which(chrLD$chri == k & chrLD$chrj == k),5])/sqrt(B)

      # p
      chrLD[which(chrLD$chri == k & chrLD$chrj == k),7] = 2*(1-pnorm(chrLD[which(chrLD$chri == k & chrLD$chrj == k),4]/chrLD[which(chrLD$chri == k & chrLD$chrj == k),6]))

      system(paste0("rm ",output,".3.core.chr",k,".zb* ",output,".3.core.chr",k,".log ",output,".3.core.chr",k,".afreq ",output,".chr",k,".xzb* "))
    }
  }

  system(paste0("rm ",output,".3.core.bed ",output,".3.core.bim ",output,".3.core.fam ",output,".3.core.log "))

  # Inter-chromosomal LD
  for(k in 1:autosome){
    if(is.na(chrLD[which(chrLD$chri==k & chrLD$chrj==k),3])){
      next
    }else{
      nchrkSNP <- chrLD[which(chrLD$chri==k & chrLD$chrj==k),3]

      xxz1 = data.frame(fread(paste0(output,".3.core.chr",k, ".sscore"), header = T))
      xxz1 = as.matrix(xxz1[,3]*xxz1[,c(5:ncol(xxz1))])
    }

    for(l in 1:autosome){
      if(is.na(chrLD[which(chrLD$chri==l & chrLD$chrj==l),3])){
        next
      }else{
        if(k < l){
          nchrlSNP <- chrLD[which(chrLD$chri==l & chrLD$chrj==l),3]
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),3] <- nchrkSNP + nchrlSNP

          xxz2 = data.frame(fread(paste0(output,".3.core.chr",l, ".sscore"), header = T))
          xxz2 = as.matrix(xxz2[,3]*xxz2[,c(5:ncol(xxz2))])

          xxz1_2 = xxz1*xxz2
          SS1_2 = colSums(xxz1_2, na.rm = T)
          LB1_2 = SS1_2/(nchrkSNP*nchrlSNP)
          trK1_2 = (sum(SS1_2)/(nchrkSNP*nchrlSNP))*(1/B)*(1/as.numeric(sc))

          # LD
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] <- (trK1_2-nIND)/(nIND*(nIND+1))

          if(chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] < 0){
            chrLD[which(chrLD$chri==k & chrLD$chrj==l),4] <- 1e-300
          }

          # variance
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),5] <- (1/(nSNP*(nSNP-1)))^2*var(LB1_2)/B

          # SE
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),6] <- sqrt(chrLD[which(chrLD$chri==k & chrLD$chrj==l),5])/sqrt(B)

          # p
          chrLD[which(chrLD$chri==k & chrLD$chrj==l),7] <- 2*(1-pnorm(chrLD[which(chrLD$chri==k & chrLD$chrj==l),4]/chrLD[which(chrLD$chri==k & chrLD$chrj==l),6]))

        }
      }

    }

  }

  system(paste0("rm ",output,".3.core.chr* ", output,".id.tmp ",
                output,".head.tmp ",output,".idzb.tmp ",output,".scoring.construct.bash ",
                output,".zb.tmp ",output,".zb.txt "))

  chrLD <- na.omit(chrLD)
  write.table(chrLD,file=paste0(output,".X-LD-Plus.txt"),quote = FALSE,sep="\t",row.names = FALSE)

  # chromosome level LD (scaled)
  chrLDscaled <- data.frame(matrix(NA,nrow=nrow(chrLD),ncol=4))
  colnames(chrLDscaled) <- c("chri","chrj","marker number","scaled LD")
  chrLDscaled[,1:3] <- chrLD[,1:3]

  for(k in 1:autosome){
    if(length(chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==k),3])==0){
      next
    }else{
      chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==k),4] <- 1
    }

    for(l in 1:autosome){
      if(length(chrLDscaled[which(chrLDscaled$chri==l & chrLDscaled$chrj==l),3])==0){
        next
      }else{
        if(k < l){
          chrkLD <- chrLD[which(chrLD$chri==k & chrLD$chrj==k),4]
          chrlLD <- chrLD[which(chrLD$chri==l & chrLD$chrj==l),4]
          chrklLD <- chrLD[which(chrLD$chri==k & chrLD$chrj==l),4]

          chrLDscaled[which(chrLDscaled$chri==k & chrLDscaled$chrj==l),4] <- chrklLD/(sqrt(chrkLD)*sqrt(chrlLD))

        }
      }
    }

  }

  chrLDscaled <- na.omit(chrLDscaled)
  write.table(chrLDscaled,file=paste0(output,".X-LD-Plus-Scaled.txt"),quote = FALSE,sep="\t",row.names = FALSE)

  # Visulation
    # unscaled
  logchrLD <- data.frame(cbind(paste0("chr",chrLD[,1]),paste0("chr",chrLD[,2]),chrLD[,3],-log10(chrLD[,4]),chrLD[,7]))
  logchrLD[,3] <- as.numeric(logchrLD[,3])
  logchrLD[,4] <- as.numeric(logchrLD[,4])
  logchrLD[,5] <- as.numeric(logchrLD[,5])
  colnames(logchrLD)[1:5] <- c("chri","chrj","marker number","-log10LD","p")

  p0.01 <- 0.01/nrow(logchrLD)
  p0.05 <- 0.05/nrow(logchrLD)

  logchrLD[which(logchrLD$p <= p0.01),6] <- "**"
  logchrLD[which(logchrLD$p > p0.01 && logchrLD$p <= p0.05),6] <- "*"
  logchrLD[which(logchrLD$p > p0.05),6] <- ""

  MAX <- as.numeric(max(logchrLD[,4]))
  MIN <- as.numeric(min(logchrLD[,4]))
  MID <- (MAX+MIN)/2

  p <- ggplot(data = logchrLD, aes(logchrLD[,2], logchrLD[,1], fill = logchrLD[,4]))+
       geom_tile(color = "white")+
       scale_fill_gradient2(low = "#FF0000", high = "#FFFFFF", mid = "#FF9E81",space = "Lab",
                            midpoint = MID, limit = c(MIN,MAX),name=expression(paste(-log[10],"LD"))) +
       geom_text(aes(label=logchrLD[,6]),col ="black",family="serif") +
       theme_minimal()+
       scale_y_discrete(position = "right") +
       theme(
                axis.title.x = element_blank(),
                axis.text.x = element_text(angle = 90,family="serif"),
                axis.title.y = element_blank(),
                axis.text.y  = element_text(family="serif"),
                panel.grid.major = element_blank(),
                panel.border = element_blank(),
                panel.background = element_blank(),
                axis.ticks = element_blank(),
                legend.text = element_text(family="serif"),
                legend.title = element_text(family="serif"),
                legend.justification = c(1, 0),
                legend.position = c(0.6, 0.7),
                legend.direction = "horizontal")+
        guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                     title.position = "top", title.hjust = 0.5)) +
        coord_fixed()
  ggsave(paste0(output,".X-LD-Plus.pdf"),p,width=8,height=8)

    # scaled
  chrLDscaled[,1:2] <- logchrLD[,1:2]
  chrLDscaled[,4] <- as.numeric(chrLDscaled[,4])
  p <- ggplot(data = chrLDscaled, aes(chrLDscaled[,2], chrLDscaled[,1], fill = chrLDscaled[,4]))+
       geom_tile(color = "white")+
       scale_fill_gradient2(low = "#FFFFFF", high = "#FF0000",mid = "#FF9E81",
                            midpoint = 0.5, limit = c(0,1), space = "Lab",
                            name="LD (scaled)") +
       theme_minimal()+
       scale_y_discrete(position = "right") +
       theme(
                axis.title.x = element_blank(),
                axis.text.x = element_text(angle = 90,family="serif"),
                axis.title.y = element_blank(),
                axis.text.y = element_text(family="serif"),
                panel.grid.major = element_blank(),
                panel.border = element_blank(),
                panel.background = element_blank(),
                axis.ticks = element_blank(),
                legend.text = element_text(family="serif"),
                legend.title = element_text(family="serif"),
                legend.justification = c(1, 0),
                legend.position = c(0.6, 0.7),
                legend.direction = "horizontal")+
        guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                     title.position = "top", title.hjust = 0.5)) +
        coord_fixed()
  ggsave(paste0(output,".X-LD-Plus-Scaled.pdf"),p,width=8,height=8)
}
