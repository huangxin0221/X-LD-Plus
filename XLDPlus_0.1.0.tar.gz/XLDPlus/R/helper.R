# Rscript to generate Zb
## pre-defined function
assign.random <- function(x){
  x = scale(stats::rnorm(length(x), 0, 1))
  x
}


